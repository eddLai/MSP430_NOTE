# 定義 slow_calc 函數（等同於 C 版本）
def slow_calc(x, a, b):
    return a * x + b

# 定義 loop_in_python 函數（等同於 C 版本）
def loop_in_python(n, a, b):
    result = 0
    for i in range(n):
        result += slow_calc(i, a, b)
    return result

# 測試運算時間
result = loop_in_python(100000000, 2, 3)
print(f"Python result: {result}")
